package com.example.setbase

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager

/** บริการเบื้องหน้า: ให้แอปทำงานต่อเมื่อปิดจอหรือสลับแอป (บลูทูธ, NTRIP, บันทึกข้อมูล) */
class KeepAliveService : Service() {
    private var wl: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        try {
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            if (Build.VERSION.SDK_INT >= 26) {
                nm.createNotificationChannel(NotificationChannel("keep", "การทำงานเบื้องหลัง", NotificationManager.IMPORTANCE_LOW))
            }
            val pi = PendingIntent.getActivity(
                this, 0,
                Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, "keep") else Notification.Builder(this)
            val n = b.setContentTitle("TU01 ทำงานเบื้องหลัง")
                .setContentText("รักษาการเชื่อมต่อบลูทูธ / NTRIP / การบันทึกข้อมูล")
                .setSmallIcon(android.R.drawable.stat_sys_data_bluetooth)
                .setContentIntent(pi)
                .setOngoing(true)
                .build()
            if (Build.VERSION.SDK_INT >= 29) {
                var t = 0
                val btOk = Build.VERSION.SDK_INT < 31 ||
                    checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
                if (btOk) t = t or ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE
                if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED)
                    t = t or ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION
                if (t == 0) {
                    stopSelf()
                    return START_NOT_STICKY
                }
                startForeground(1, n, t)
            } else {
                startForeground(1, n)
            }
            if (wl == null) {
                val pm = getSystemService(POWER_SERVICE) as PowerManager
                wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "setbase:keep")
                wl?.setReferenceCounted(false)
            }
            if (wl?.isHeld != true) wl?.acquire()
        } catch (e: Exception) {
            stopSelf()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        try {
            if (wl?.isHeld == true) wl?.release()
        } catch (e: Exception) {
        }
        wl = null
        super.onDestroy()
    }
}
