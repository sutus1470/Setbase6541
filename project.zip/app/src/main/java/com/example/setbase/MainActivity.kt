package com.example.setbase

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothSocket
import android.content.ClipData
import android.content.Intent
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.util.Base64
import android.view.WindowInsets
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONArray
import org.json.JSONObject
import java.io.InputStream
import java.net.InetSocketAddress
import java.net.Socket
import java.util.UUID

/**
 * Setbase: WebView ที่โหลด assets/setbase.html
 * และเปิดสะพาน "AndroidBT" ให้หน้าเว็บใช้ Bluetooth Classic (SPP) เช่น HC-04
 */
class MainActivity : Activity() {

    private lateinit var web: WebView

    @Volatile
    private var socket: BluetoothSocket? = null

    @Volatile
    private var busy = false

    private val sppUuid: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    private val reqBt = 1001

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)

        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowContentAccess = false
        web.webChromeClient = WebChromeClient()
        web.webViewClient = object : WebViewClient() {
            // อนุญาตเฉพาะหน้าในแอป ไม่เปิดเว็บภายนอก
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                return !request.url.toString().startsWith("file:///android_asset/")
            }
        }
        web.addJavascriptInterface(Bridge(), "AndroidBT")

        // Android 15 ขึ้นไปวาดเต็มจอ จึงเว้นขอบตามแถบระบบ
        if (Build.VERSION.SDK_INT >= 35) {
            web.setOnApplyWindowInsetsListener { v, insets ->
                val b = insets.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.ime())
                v.setPadding(b.left, b.top, b.right, b.bottom)
                insets
            }
        }

        web.loadUrl("file:///android_asset/setbase.html")
        requestBtPermission()
    }

    private fun hasBtPermission(): Boolean =
        Build.VERSION.SDK_INT < 31 ||
            (checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED &&
                checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED)

    private fun requestBtPermission() {
        if (!hasBtPermission()) {
            requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN), reqBt)
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == reqBt) js("window.bnatRefresh&&window.bnatRefresh()")
    }

    private fun adapter(): BluetoothAdapter? =
        (getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter

    private fun js(code: String) {
        runOnUiThread { web.evaluateJavascript(code, null) }
    }

    private fun status(msg: String, connected: Boolean) {
        js("window.onBtStatus&&window.onBtStatus(" + JSONObject.quote(msg) + "," + connected + ")")
    }

    private fun push(text: String) {
        js("window.onBtData&&window.onBtData(" + JSONObject.quote(text) + ")")
    }


    // ---------------- NTRIP ----------------
    private val btLock = Any()

    @Volatile
    private var ntrip: Socket? = null

    @Volatile
    private var ntripBusy = false

    @Volatile
    private var lastGga: String = ""

    @Volatile
    private var rtcmSink: ((ByteArray, Int) -> Unit)? = null

    private val ggaBuf = StringBuilder()

    private fun btWrite(b: ByteArray, n: Int): Boolean {
        val s = socket ?: return false
        return try {
            synchronized(btLock) {
                val o = s.outputStream
                o.write(b, 0, n)
                o.flush()
            }
            true
        } catch (e: Exception) {
            false
        }
    }

    /** ข้อมูลที่อ่านได้จากเครื่องรับทางบลูทูธ */
    private fun onBtBytes(buf: ByteArray, n: Int) {
        for (i in 0 until n) {
            val c = buf[i].toInt() and 0xFF
            if (c == 10) {
                val l = ggaBuf.toString().trim()
                if (l.startsWith("\$") && l.contains("GGA,")) lastGga = l
                ggaBuf.setLength(0)
            } else if (c in 32..126) {
                if (ggaBuf.length < 200) ggaBuf.append(c.toChar())
            } else if (c != 13) {
                ggaBuf.setLength(0)
            }
        }
        val sink = rtcmSink
        if (sink != null) sink(buf, n) else push(String(buf, 0, n, Charsets.ISO_8859_1))
    }

    /** แยกเฟรม RTCM3 (0xD3 + ความยาว + CRC24Q) ออกจากข้อมูลที่ปนกับ NMEA */
    private class RtcmFramer(val onFrame: (ByteArray, Int) -> Unit) {
        private val buf = ByteArray(2048)
        private var len = 0

        private fun crc(d: ByteArray, n: Int): Int {
            var c = 0
            for (i in 0 until n) {
                c = c xor ((d[i].toInt() and 0xFF) shl 16)
                for (j in 0 until 8) {
                    c = c shl 1
                    if ((c and 0x1000000) != 0) c = c xor 0x1864CFB
                }
            }
            return c and 0xFFFFFF
        }

        private fun dropLead(k: Int) {
            var s = k
            while (s < len && (buf[s].toInt() and 0xFF) != 0xD3) s++
            val rest = len - s
            if (rest > 0) System.arraycopy(buf, s, buf, 0, rest)
            len = if (rest > 0) rest else 0
        }

        private fun drain() {
            while (len >= 3) {
                if ((buf[1].toInt() and 0xFC) != 0) {
                    dropLead(1)
                    continue
                }
                val pl = ((buf[1].toInt() and 3) shl 8) or (buf[2].toInt() and 0xFF)
                val total = pl + 6
                if (len < total) return
                val got = ((buf[total - 3].toInt() and 0xFF) shl 16) or
                    ((buf[total - 2].toInt() and 0xFF) shl 8) or
                    (buf[total - 1].toInt() and 0xFF)
                if (crc(buf, total - 3) == got) {
                    val type = ((buf[3].toInt() and 0xFF) shl 4) or ((buf[4].toInt() and 0xFF) shr 4)
                    onFrame(buf.copyOf(total), type)
                    dropLead(total)
                } else {
                    dropLead(1)
                }
            }
        }

        fun feed(b: ByteArray, n: Int) {
            for (i in 0 until n) {
                if (len == 0 && (b[i].toInt() and 0xFF) != 0xD3) continue
                buf[len++] = b[i]
                drain()
            }
        }
    }

    private fun ntripStatus(msg: String, state: Int) {
        js("window.onNtrip&&window.onNtrip(" + JSONObject.quote(msg) + "," + state + ")")
    }

    private fun keepAwake(on: Boolean) {
        runOnUiThread {
            if (on) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
    }

    private fun readLine(inp: InputStream): String {
        val sb = StringBuilder()
        while (true) {
            val c = inp.read()
            if (c < 0 || c == 10) break
            if (c != 13) sb.append(c.toChar())
            if (sb.length > 400) break
        }
        return sb.toString()
    }

    private fun kb(n: Long): String = String.format(java.util.Locale.US, "%.1f KB", n / 1024.0)

    private fun runNtrip(
        mode: String, host: String, port: Int, mount: String,
        user: String, pass: String, ver: Int, sendGga: Boolean
    ) {
        var msg = ""
        val sock = Socket()
        try {
            ntripStatus("กำลังเชื่อมต่อ $host:$port ...", 1)
            sock.connect(InetSocketAddress(host, port), 12000)
            sock.tcpNoDelay = true
            ntrip = sock
            val out = sock.getOutputStream()
            val inp = sock.getInputStream()
            val auth = Base64.encodeToString("$user:$pass".toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
            val ua = "NTRIP SetbaseApp/1.0"
            val req = if (mode == "server") {
                if (ver == 1) {
                    "SOURCE $pass /$mount\r\nSource-Agent: $ua\r\n\r\n"
                } else {
                    "POST /$mount HTTP/1.1\r\nHost: $host:$port\r\nNtrip-Version: Ntrip/2.0\r\n" +
                        "Authorization: Basic $auth\r\nUser-Agent: $ua\r\nConnection: close\r\n\r\n"
                }
            } else {
                if (ver == 1) {
                    "GET /$mount HTTP/1.0\r\nUser-Agent: $ua\r\nAuthorization: Basic $auth\r\n\r\n"
                } else {
                    "GET /$mount HTTP/1.1\r\nHost: $host:$port\r\nNtrip-Version: Ntrip/2.0\r\n" +
                        "User-Agent: $ua\r\nAuthorization: Basic $auth\r\nConnection: close\r\n\r\n"
                }
            }
            out.write(req.toByteArray(Charsets.ISO_8859_1))
            out.flush()

            val first = readLine(inp)
            var chunked = false
            if (first.startsWith("HTTP/")) {
                while (true) {
                    val h = readLine(inp)
                    if (h.isEmpty()) break
                    if (h.lowercase().startsWith("transfer-encoding") && h.lowercase().contains("chunked")) chunked = true
                }
            }
            val okResp = first.startsWith("ICY 200") || (first.startsWith("HTTP/") && first.contains(" 200"))
            if (!okResp) {
                msg = when {
                    first.contains("401") -> "ชื่อผู้ใช้/รหัสผ่านไม่ถูกต้อง (401)"
                    first.contains("403") -> "ไม่ได้รับอนุญาต (403)"
                    first.contains("404") || first.startsWith("SOURCETABLE") -> "ไม่พบ Mountpoint นี้ที่ caster"
                    first.isEmpty() -> "caster ไม่ตอบกลับ"
                    else -> "caster ตอบ: $first"
                }
                return
            }

            keepAwake(true)
            val t0 = System.currentTimeMillis()
            var lastRep = 0L
            if (mode == "server") {
                var frames = 0
                var bytes = 0L
                val types = java.util.TreeSet<Int>()
                val framer = RtcmFramer { frame, type ->
                    try {
                        out.write(frame)
                        out.flush()
                        frames++
                        bytes += frame.size
                        types.add(type)
                    } catch (e: Exception) {
                        try { sock.close() } catch (ignored: Exception) { }
                    }
                }
                rtcmSink = { b, n ->
                    framer.feed(b, n)
                    val now = System.currentTimeMillis()
                    if (now - lastRep > 1000) {
                        lastRep = now
                        ntripStatus("ส่งขึ้น caster แล้ว: $frames ข้อความ (" + kb(bytes) + ") ชนิด " + types.joinToString(","), 2)
                    }
                }
                ntripStatus("เชื่อมต่อ caster แล้ว รอข้อมูล RTCM จากเครื่องรับ...", 2)
                val tmp = ByteArray(256)
                while (inp.read(tmp) >= 0) { }
                msg = "caster ตัดการเชื่อมต่อ"
            } else {
                if (sendGga) {
                    Thread {
                        var t = 0L
                        while (ntrip === sock && !sock.isClosed) {
                            val now = System.currentTimeMillis()
                            if (now - t >= 10000 && lastGga.isNotEmpty()) {
                                try {
                                    out.write((lastGga + "\r\n").toByteArray(Charsets.ISO_8859_1))
                                    out.flush()
                                    t = now
                                } catch (e: Exception) {
                                    break
                                }
                            }
                            try { Thread.sleep(500) } catch (e: Exception) { break }
                        }
                    }.start()
                }
                ntripStatus("เชื่อมต่อ caster แล้ว รอข้อมูล...", 2)
                var total = 0L
                val buf = ByteArray(2048)
                fun deliver(b: ByteArray, n: Int) {
                    if (!btWrite(b, n)) throw Exception("ส่งเข้าเครื่องรับทางบลูทูธไม่ได้ (บลูทูธหลุด?)")
                    total += n
                    val now = System.currentTimeMillis()
                    if (now - lastRep > 1000) {
                        lastRep = now
                        ntripStatus("รับจาก caster แล้ว " + kb(total) + " ส่งเข้าเครื่องรับ (" + ((now - t0) / 1000) + " วินาที)", 2)
                    }
                }
                if (!chunked) {
                    while (true) {
                        val n = inp.read(buf)
                        if (n < 0) break
                        if (n > 0) deliver(buf, n)
                    }
                } else {
                    while (true) {
                        val sz = readLine(inp).trim().substringBefore(';').ifEmpty { "0" }.toInt(16)
                        if (sz <= 0) break
                        var left = sz
                        while (left > 0) {
                            val n = inp.read(buf, 0, minOf(left, buf.size))
                            if (n < 0) throw Exception("caster ตัดการเชื่อมต่อ")
                            deliver(buf, n)
                            left -= n
                        }
                        readLine(inp)
                    }
                }
                msg = "caster ตัดการเชื่อมต่อ"
            }
        } catch (e: Exception) {
            if (msg.isEmpty()) msg = if (sock.isClosed) "ตัดการเชื่อมต่อ NTRIP แล้ว" else "NTRIP ผิดพลาด: " + (e.message ?: e.javaClass.simpleName)
        } finally {
            rtcmSink = null
            ntrip = null
            try { sock.close() } catch (ignored: Exception) { }
            ntripBusy = false
            keepAwake(false)
            ntripStatus(if (msg.isEmpty()) "ตัดการเชื่อมต่อ NTRIP แล้ว" else msg, 0)
        }
    }

    private fun fetchTable(host: String, port: Int, user: String, pass: String) {
        try {
            val sock = Socket()
            sock.connect(InetSocketAddress(host, port), 12000)
            sock.soTimeout = 15000
            val sb = StringBuilder("GET / HTTP/1.0\r\nUser-Agent: NTRIP SetbaseApp/1.0\r\n")
            if (user.isNotEmpty()) {
                sb.append("Authorization: Basic " + Base64.encodeToString("$user:$pass".toByteArray(Charsets.UTF_8), Base64.NO_WRAP) + "\r\n")
            }
            sb.append("\r\n")
            sock.getOutputStream().write(sb.toString().toByteArray(Charsets.ISO_8859_1))
            sock.getOutputStream().flush()
            val inp = sock.getInputStream()
            val text = StringBuilder()
            val b = ByteArray(4096)
            while (text.length < 600000) {
                val n = try { inp.read(b) } catch (e: Exception) { -1 }
                if (n < 0) break
                text.append(String(b, 0, n, Charsets.ISO_8859_1))
                if (text.contains("ENDSOURCETABLE")) break
            }
            try { sock.close() } catch (ignored: Exception) { }
            val arr = JSONArray()
            for (line in text.split("\n")) {
                val l = line.trim()
                if (!l.startsWith("STR;")) continue
                val f = l.split(";")
                if (f.size < 4) continue
                arr.put(JSONObject().put("m", f[1]).put("id", f[2]).put("fmt", f[3]))
            }
            val res = JSONObject()
            if (arr.length() == 0) res.put("err", "ไม่พบรายการ mountpoint (ตรวจ Host/Port หรือรหัสผ่าน)") else res.put("list", arr)
            js("window.onNtripTable&&window.onNtripTable(" + JSONObject.quote(res.toString()) + ")")
        } catch (e: Exception) {
            val res = JSONObject().put("err", "ดึงรายการไม่ได้: " + (e.message ?: ""))
            js("window.onNtripTable&&window.onNtripTable(" + JSONObject.quote(res.toString()) + ")")
        }
    }

    override fun onDestroy() {
        try {
            ntrip?.close()
        } catch (ignored: Exception) {
        }
        try {
            socket?.close()
        } catch (ignored: Exception) {
        }
        super.onDestroy()
    }

    inner class Bridge {

        /** รายการอุปกรณ์ที่จับคู่ไว้แล้ว เป็น JSON: {"ok":true,"devices":[{"name":..,"address":..}]} */
        @JavascriptInterface
        fun listPaired(): String {
            val out = JSONObject()
            if (!hasBtPermission()) {
                runOnUiThread { requestBtPermission() }
                return out.put("ok", false).put("err", "perm").toString()
            }
            val ad = adapter()
            if (ad == null || !ad.isEnabled) {
                return out.put("ok", false).put("err", "off").toString()
            }
            val arr = JSONArray()
            try {
                for (d in ad.bondedDevices) {
                    arr.put(JSONObject().put("name", d.name ?: "?").put("address", d.address))
                }
            } catch (e: SecurityException) {
                return out.put("ok", false).put("err", "perm").toString()
            }
            return out.put("ok", true).put("devices", arr).toString()
        }

        @JavascriptInterface
        fun connect(address: String) {
            if (busy) return
            busy = true
            Thread {
                var connected = false
                var msg = ""
                try {
                    if (!hasBtPermission()) throw Exception("ยังไม่ได้รับอนุญาตใช้บลูทูธ")
                    val ad = adapter() ?: throw Exception("ไม่พบบลูทูธในเครื่อง")
                    val dev = ad.getRemoteDevice(address)
                    status("กำลังเชื่อมต่อ...", false)

                    var s: BluetoothSocket = dev.createRfcommSocketToServiceRecord(sppUuid)
                    try {
                        s.connect()
                    } catch (e1: Exception) {
                        try {
                            s.close()
                        } catch (ignored: Exception) {
                        }
                        // วิธีสำรองสำหรับโมดูลบางรุ่นที่ต่อด้วย UUID ปกติไม่ได้
                        try {
                            val m = dev.javaClass.getMethod("createRfcommSocket", Int::class.javaPrimitiveType)
                            s = m.invoke(dev, 1) as BluetoothSocket
                            s.connect()
                        } catch (e2: Exception) {
                            throw e1
                        }
                    }

                    socket = s
                    connected = true
                    status("เชื่อมต่อแล้ว: " + (dev.name ?: address), true)

                    val buf = ByteArray(1024)
                    val input = s.inputStream
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        if (n > 0) onBtBytes(buf, n)
                    }
                    msg = "ตัดการเชื่อมต่อแล้ว"
                } catch (e: Exception) {
                    msg = if (connected) "ตัดการเชื่อมต่อแล้ว" else "เชื่อมต่อไม่สำเร็จ: " + (e.message ?: "")
                } finally {
                    try {
                        socket?.close()
                    } catch (ignored: Exception) {
                    }
                    socket = null
                    busy = false
                    status(msg, false)
                }
            }.start()
        }

        @JavascriptInterface
        fun disconnect() {
            try {
                socket?.close()
            } catch (ignored: Exception) {
            }
        }

        /** ส่งข้อความไปยังอุปกรณ์ (ข้อความ ASCII) คืน true เมื่อส่งสำเร็จ */
        @JavascriptInterface
        fun send(text: String): Boolean {
            val b = text.toByteArray(Charsets.ISO_8859_1)
            return btWrite(b, b.size)
        }

        /** เริ่ม NTRIP: mode = "client" (รับ) หรือ "server" (ส่งจากฐาน) */
        @JavascriptInterface
        fun ntripStart(
            mode: String, host: String, port: Int, mount: String,
            user: String, pass: String, ver: Int, sendGga: Boolean
        ) {
            if (ntripBusy) return
            if (socket == null) {
                ntripStatus("ต้องเชื่อมต่อบลูทูธกับเครื่องรับก่อน", 0)
                return
            }
            ntripBusy = true
            Thread { runNtrip(mode, host, port, mount, user, pass, ver, sendGga) }.start()
        }

        @JavascriptInterface
        fun ntripStop() {
            try {
                ntrip?.close()
            } catch (ignored: Exception) {
            }
        }

        @JavascriptInterface
        fun ntripTable(host: String, port: Int, user: String, pass: String) {
            Thread { fetchTable(host, port, user, pass) }.start()
        }

        /** บันทึกไฟล์ CSV ลงโฟลเดอร์ Download/Setbase (Android 10 ขึ้นไป) หรือเปิดหน้าต่างแชร์ (รุ่นเก่ากว่า) */
        @JavascriptInterface
        fun saveFile(name: String, text: String): String {
            return try {
                val safe = name.replace(Regex("[\\\\/:*?\"<>|]"), "_")
                val bytes = byteArrayOf(0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte()) + text.toByteArray(Charsets.UTF_8)
                if (Build.VERSION.SDK_INT >= 29) {
                    val v = ContentValues()
                    v.put(MediaStore.MediaColumns.DISPLAY_NAME, safe)
                    v.put(MediaStore.MediaColumns.MIME_TYPE, "text/csv")
                    v.put(MediaStore.MediaColumns.RELATIVE_PATH, "Download/Setbase")
                    val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v)
                        ?: return "err:สร้างไฟล์ไม่ได้"
                    contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
                    "ok:Download/Setbase/" + safe
                } else {
                    runOnUiThread {
                        try {
                            val i = Intent(Intent.ACTION_SEND)
                            i.type = "text/plain"
                            i.putExtra(Intent.EXTRA_SUBJECT, safe)
                            i.putExtra(Intent.EXTRA_TEXT, text)
                            startActivity(Intent.createChooser(i, safe))
                        } catch (e: Exception) {
                        }
                    }
                    "share"
                }
            } catch (e: Exception) {
                "err:" + (e.message ?: "")
            }
        }

        /** เปิดลิงก์ Google Maps ในแอปแผนที่/เบราว์เซอร์ของเครื่อง (เฉพาะ https://www.google.com/maps) */
        @JavascriptInterface
        fun openUrl(url: String) {
            if (!url.startsWith("https://www.google.com/maps")) return
            runOnUiThread {
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                } catch (e: Exception) {
                }
            }
        }

        /** คัดลอกข้อความลงคลิปบอร์ด (navigator.clipboard ใช้ไม่ได้ในหน้าไฟล์) */
        @JavascriptInterface
        fun copy(text: String) {
            runOnUiThread {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("Setbase", text))
            }
        }
    }
}
