package com.example.setbase

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothSocket
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.WindowInsets
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/**
 * Setbase: WebView ที่โหลด assets/setbase.html
 * และเปิดสะพาน "AndroidBT" ให้หน้าเว็บใช้ Bluetooth Classic (SPP) เช่น HC-04
 */
class MainActivity : Activity() {

    private lateinit var web: WebView

    @Volatile
    private var socket: BluetoothSocket? = null

    @Volatile
    private var busy = false

    private val sppUuid: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    private val reqBt = 1001

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)

        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowContentAccess = false
        web.webChromeClient = WebChromeClient()
        web.webViewClient = object : WebViewClient() {
            // อนุญาตเฉพาะหน้าในแอป ไม่เปิดเว็บภายนอก
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                return !request.url.toString().startsWith("file:///android_asset/")
            }
        }
        web.addJavascriptInterface(Bridge(), "AndroidBT")

        // Android 15 ขึ้นไปวาดเต็มจอ จึงเว้นขอบตามแถบระบบ
        if (Build.VERSION.SDK_INT >= 35) {
            web.setOnApplyWindowInsetsListener { v, insets ->
                val b = insets.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.ime())
                v.setPadding(b.left, b.top, b.right, b.bottom)
                insets
            }
        }

        web.loadUrl("file:///android_asset/setbase.html")
        requestBtPermission()
    }

    private fun hasBtPermission(): Boolean =
        Build.VERSION.SDK_INT < 31 ||
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED

    private fun requestBtPermission() {
        if (!hasBtPermission()) {
            requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), reqBt)
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == reqBt) js("window.bnatList&&window.bnatList()")
    }

    private fun adapter(): BluetoothAdapter? =
        (getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter

    private fun js(code: String) {
        runOnUiThread { web.evaluateJavascript(code, null) }
    }

    private fun status(msg: String, connected: Boolean) {
        js("window.onBtStatus&&window.onBtStatus(" + JSONObject.quote(msg) + "," + connected + ")")
    }

    private fun push(text: String) {
        js("window.onBtData&&window.onBtData(" + JSONObject.quote(text) + ")")
    }

    override fun onDestroy() {
        try {
            socket?.close()
        } catch (ignored: Exception) {
        }
        super.onDestroy()
    }

    inner class Bridge {

        /** รายการอุปกรณ์ที่จับคู่ไว้แล้ว เป็น JSON: {"ok":true,"devices":[{"name":..,"address":..}]} */
        @JavascriptInterface
        fun listPaired(): String {
            val out = JSONObject()
            if (!hasBtPermission()) {
                runOnUiThread { requestBtPermission() }
                return out.put("ok", false).put("err", "perm").toString()
            }
            val ad = adapter()
            if (ad == null || !ad.isEnabled) {
                return out.put("ok", false).put("err", "off").toString()
            }
            val arr = JSONArray()
            try {
                for (d in ad.bondedDevices) {
                    arr.put(JSONObject().put("name", d.name ?: "?").put("address", d.address))
                }
            } catch (e: SecurityException) {
                return out.put("ok", false).put("err", "perm").toString()
            }
            return out.put("ok", true).put("devices", arr).toString()
        }

        @JavascriptInterface
        fun connect(address: String) {
            if (busy) return
            busy = true
            Thread {
                var connected = false
                var msg = ""
                try {
                    if (!hasBtPermission()) throw Exception("ยังไม่ได้รับอนุญาตใช้บลูทูธ")
                    val ad = adapter() ?: throw Exception("ไม่พบบลูทูธในเครื่อง")
                    val dev = ad.getRemoteDevice(address)
                    status("กำลังเชื่อมต่อ...", false)
                    ad.cancelDiscovery()

                    var s: BluetoothSocket = dev.createRfcommSocketToServiceRecord(sppUuid)
                    try {
                        s.connect()
                    } catch (e1: Exception) {
                        try {
                            s.close()
                        } catch (ignored: Exception) {
                        }
                        // วิธีสำรองสำหรับโมดูลบางรุ่นที่ต่อด้วย UUID ปกติไม่ได้
                        try {
                            val m = dev.javaClass.getMethod("createRfcommSocket", Int::class.javaPrimitiveType)
                            s = m.invoke(dev, 1) as BluetoothSocket
                            s.connect()
                        } catch (e2: Exception) {
                            throw e1
                        }
                    }

                    socket = s
                    connected = true
                    status("เชื่อมต่อแล้ว: " + (dev.name ?: address), true)

                    val buf = ByteArray(1024)
                    val input = s.inputStream
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        if (n > 0) push(String(buf, 0, n, Charsets.ISO_8859_1))
                    }
                    msg = "ตัดการเชื่อมต่อแล้ว"
                } catch (e: Exception) {
                    msg = if (connected) "ตัดการเชื่อมต่อแล้ว" else "เชื่อมต่อไม่สำเร็จ: " + (e.message ?: "")
                } finally {
                    try {
                        socket?.close()
                    } catch (ignored: Exception) {
                    }
                    socket = null
                    busy = false
                    status(msg, false)
                }
            }.start()
        }

        @JavascriptInterface
        fun disconnect() {
            try {
                socket?.close()
            } catch (ignored: Exception) {
            }
        }

        /** ส่งข้อความไปยังอุปกรณ์ (ข้อความ ASCII) คืน true เมื่อส่งสำเร็จ */
        @JavascriptInterface
        fun send(text: String): Boolean {
            val s = socket ?: return false
            return try {
                val o = s.outputStream
                o.write(text.toByteArray(Charsets.ISO_8859_1))
                o.flush()
                true
            } catch (e: Exception) {
                false
            }
        }

        /** คัดลอกข้อความลงคลิปบอร์ด (navigator.clipboard ใช้ไม่ได้ในหน้าไฟล์) */
        @JavascriptInterface
        fun copy(text: String) {
            runOnUiThread {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("Setbase", text))
            }
        }
    }
}
